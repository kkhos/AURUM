from __future__ import print_function
import os
import sys
sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(os.path.dirname(__file__)))))
from aurum_pb2 import *
from aurum_pb2_grpc import BootstrapStub
import logging
import grpc
import time

def sampleFunc(stub):
    print("Hello World")

def runTest(stub, testFunc):
    print("Testing started :", testFunc)
    result = testFunc(stub)
    print("Testing result :", result)

def run():
    with grpc.insecure_channel('127.0.0.1:50051') as channel:
        stub = BootstrapStub(channel)
        # Start
        runTest(stub, sampleFunc)

if __name__ == '__main__':
    logging.basicConfig()
    run()
