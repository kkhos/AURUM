# AurumTestScript

The script writing guide and script management policy will be updated later.
