import os
import time

from aurum_pb2 import *

# TODO This library is under construction - it should be cleaned up in future

#========================================================================
# UTILS (helper functions to be reused in NUI Accessibility tests)
#========================================================================

# The test app name that is to be used with Accessibility automated tests
TEST_APP_NAME = 'org.tizen.example.NUITestApp'

# The screen dimensions and other parameters
# that will be used to emulate gestures
SCREEN_WIDTH = 720
SCREEN_HEIGHT = 1280
MARGIN = 5
ACTION_DELAY_SHORT = 0.5
ACTION_DELAY_LONG = 1
ACTION_DELAY_XLONG = 3
FLICK_DURATION_MILISECONDS = 110
DRAG_DURATION_MILISECONDS = 2000

# Runs a shell command
def run_command(command):
    stream = os.popen(command)
    output = stream.read()

# Launches the test app
def LAUNCH_TEST_APP(stub):
    stub.launchApp(ReqLaunchApp(packageName=TEST_APP_NAME))
    time.sleep(ACTION_DELAY_LONG)

# Closes the test app
def CLOSE_TEST_APP(stub):
    stub.closeApp(ReqCloseApp(packageName=TEST_APP_NAME))
    time.sleep(ACTION_DELAY_LONG)

# Checks if the app is running
def IS_RUNNING_TEST_APP(stub):
    return stub.getAppInfo(ReqGetAppInfo(packageName=TEST_APP_NAME)).isRunning

# Check if keyboard is shown
# TODO this does not work, the ise-default is always running!
# On the other hand, isFocused property is always false.
# Moreover, calling this function in two TCs causes test suite freeze on the function call in the second TC (why?)
def IS_KEYBOARD_SHOWN(stub):
    return stub.getAppInfo(ReqGetAppInfo(packageName='ise-default')).isRunning

# Launches or relaunches the test app if needed
def RELAUNCH_TEST_APP(stub):
    if IS_RUNNING_TEST_APP(stub):
        CLOSE_TEST_APP(stub)
    LAUNCH_TEST_APP(stub)

# Starts Screen Reader (Accessibility mode on)
def SR_START():
    run_command("sdb root on")
    run_command("sdb shell vconftool set -f -t bool db/setting/accessibility/tts 1")
    time.sleep(ACTION_DELAY_LONG)

# Stops Screen Reader (Accessibility mode off)
def SR_STOP():
    run_command("sdb root on")
    run_command("sdb shell vconftool set -f -t bool db/setting/accessibility/tts 0")
    time.sleep(ACTION_DELAY_LONG)

# Finds an object with given A11y label
# Returns an elementId of the found object or False otherwise.
def findWidget(stub, name, type=None):
    response = stub.findElement(ReqFindElement(textField=name, widgetType=type))
    if len(response.elements) <= 0: return False
    targetId = response.elements[0].elementId
    return targetId

def hasWidgetText(control, text):
    return bool(control) and control.text == text

# Finds an object with given automationId
# Returns the found object or False otherwise.
def getObjectByAutomationId(stub, autoId):
    response = stub.findElement(ReqFindElement(automationId=autoId, widgetType=None))
    if len(response.elements) <= 0: return False
    target = response.elements[0]
    return target

# Prints ohbject data by name
def printWidgetInfo(stub, name, type=None):
    elemId = findWidget(stub, name, type)
    print("===========================")
    if elemId:
        response = stub.dumpObjectTree(ReqDumpObjectTree(elementId=elemId))
        print(response.roots)
    else:
        print("OBJECT NOT FOUND")
    print("===========================")
        

# Prints object data by elementId
def printObjectByAutomationId(stub, autoId):
    obj = getObjectByAutomationId(stub, autoId)
    response = stub.dumpObjectTree(ReqDumpObjectTree(elementId=obj.elementId))
    print("===========================")
    print(response.roots)
    print("===========================")

# Prints current object tree
def printTree(stub):
    response = stub.findElement(ReqFindElement(maxDepth=1, minDepth=1, isShowing=True))
    print("===========================")
    print(response)
    for i in response.elements:
        response = stub.dumpObjectTree(ReqDumpObjectTree(elementId=i.elementId))
    print(response.roots)
    print("===========================")

# Checks if the object has accessibility highlight
# i.e. it is wrapped in an accessibility highlight frame.
# Most proper way to do this would be to check the AT-SPI2 HIGHLIGHTED state,
# but it does not seem to be possible yet using Aurum API.
# So the following workaround is done:
# In the test app a custom highlight frame is created
# and an AutomationId of the frame is set to "custom_highlight".
# Then, in the test, we check whether this frame exist and whether it has
# the same size and position as the object we expect to be highlighted.
def isHighlightedObject(stub, obj, highlightId="custom_highlight"):
    if not obj:
        return False
    highlight = getObjectByAutomationId(stub, highlightId)
    if highlight and obj.geometry == highlight.geometry:
        return True
    return False

# Helper function doing the same as isHighlightedObject
# but taking as a parameter an AutomationId of the object being checked.
def isHighlighted(stub, automationId, highlightId="custom_highlight"):
    obj = getObjectByAutomationId(stub, automationId)
    return isHighlightedObject(stub, obj, highlightId)

# Emulate pressing HW Back button
def BACK(stub):
    response = stub.sendKey(ReqKey(type='BACK', actionType='STROKE'))

# Emulate pressing an object with given A11y label
def TAP_BY_NAME(stub, name, type=None):
    id = findWidget(stub, name, type)
    if id:
        stub.click(ReqClick(type='ELEMENTID', elementId=id))
        time.sleep(ACTION_DELAY_SHORT)
        return True
    else:
        return False
        
# Emulate double-tap gesture on an object with given A11y label
def DOUBLE_TAP_BY_NAME(stub, name):
    id = findWidget(stub, name)
    if id:
        stub.click(ReqClick(type='ELEMENTID', elementId=id))
        stub.click(ReqClick(type='ELEMENTID', elementId=id))
        time.sleep(ACTION_DELAY_SHORT)
        return True
    else:
        return False

# Emulate double tap MIDDLE by double tapping in the middle of the screen
def DOUBLE_TAP_MIDDLE(stub):
    stub.click(ReqClick(coordination=Point(x=SCREEN_WIDTH//2, y=SCREEN_HEIGHT//2), type='COORD'))
    stub.click(ReqClick(coordination=Point(x=SCREEN_WIDTH//2, y=SCREEN_HEIGHT//2), type='COORD'))
    time.sleep(ACTION_DELAY_SHORT)

# Emulate Accessibility "highlight at point" gesture
# by tapping an object with given AutomationID
def TAP_BY_AUTOMATION_ID(stub, autoId):
    obj = getObjectByAutomationId(stub, autoId)
    if obj:
        stub.click(ReqClick(type='ELEMENTID', elementId=obj.elementId))
        time.sleep(ACTION_DELAY_SHORT)
        return True
    else:
        return False

# Emulate Accessibility "highlight at point" gesture
# by tapping an object with given name and type
def TAP(stub, name, type=None):
    return TAP_BY_NAME(stub, name, type)

# Emulate Accessibility "activate" gesture
# which is double tap MIDDLE on the screen
def DOUBLE_TAP(stub):
    DOUBLE_TAP_MIDDLE(stub)

# Emulate Accessibility "next" gesture
# which is flick right MIDDLE on the screen
def FLICK_RIGHT(stub):
    stub.flick(ReqFlick(startPoint=Point(x=MARGIN, y=SCREEN_HEIGHT//2), endPoint=Point(x=SCREEN_WIDTH-MARGIN, y=SCREEN_HEIGHT//2), durationMs=FLICK_DURATION_MILISECONDS))
    time.sleep(ACTION_DELAY_LONG)

# Emulate Accessibility "prev" gesture
# which is flick left MIDDLE on the screen
def FLICK_LEFT(stub):
    stub.flick(ReqFlick(startPoint=Point(x=SCREEN_WIDTH-MARGIN, y=SCREEN_HEIGHT//2), endPoint=Point(x=MARGIN, y=SCREEN_HEIGHT//2), durationMs=FLICK_DURATION_MILISECONDS))
    time.sleep(ACTION_DELAY_LONG)

# Emulate flick down gesture
def FLICK_DOWN(stub):
    stub.flick(ReqFlick(startPoint=Point(x=SCREEN_WIDTH//2, y=SCREEN_HEIGHT//4), endPoint=Point(x=SCREEN_WIDTH//2, y=SCREEN_HEIGHT//2), durationMs=FLICK_DURATION_MILISECONDS))
    time.sleep(ACTION_DELAY_LONG)

# Emulate flick up gesture
def FLICK_UP(stub):
    stub.flick(ReqFlick(startPoint=Point(x=SCREEN_WIDTH//2, y=SCREEN_HEIGHT//2), endPoint=Point(x=SCREEN_WIDTH//2, y=SCREEN_HEIGHT//4), durationMs=FLICK_DURATION_MILISECONDS))
    time.sleep(ACTION_DELAY_LONG)

# Emulate 1-finger drag down
# TODO find out how to emulate 2-finger drag    
def DRAG_DOWN_1F(stub):
    stub.flick(ReqFlick(startPoint=Point(x=SCREEN_WIDTH//2, y=MARGIN), endPoint=Point(x=SCREEN_WIDTH//2, y=SCREEN_HEIGHT-MARGIN), durationMs=DRAG_DURATION_MILISECONDS))

# Emulate 1-finger drag down
# TODO find out how to emulate 2-finger drag  
def DRAG_UP_1F(stub):
    stub.flick(ReqFlick(startPoint=Point(x=SCREEN_WIDTH//2, y=SCREEN_HEIGHT-MARGIN), endPoint=Point(x=SCREEN_WIDTH//2, y=MARGIN), durationMs=DRAG_DURATION_MILISECONDS))
    
def PRESS_XF86_KEY(stub, keyCode):
    stub.sendKey(ReqKey(type='XF86', actionType='STROKE', XF86keyCode=keyCode))
