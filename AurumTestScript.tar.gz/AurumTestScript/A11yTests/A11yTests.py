import logging
import time

import grpc

from aurum_pb2 import *
from aurum_pb2_grpc import BootstrapStub
from a11y_test_utils import *

#========================================================================
# TESTS (here are individual test cases for Screen Reader)
#========================================================================

# Start Screen Reader and launch application.
def launchAppTest(stub):
    SR_START()
    RELAUNCH_TEST_APP(stub)
    return IS_RUNNING_TEST_APP(stub)

# Close application and stop Screen Reader.
def closeAppTest(stub):
    CLOSE_TEST_APP(stub)
    return IS_RUNNING_TEST_APP(stub) != True

def launchAppTestNoSR(stub):
    SR_STOP()
    RELAUNCH_TEST_APP(stub)
    return IS_RUNNING_TEST_APP(stub)

# Close application.
def closeAppTestNoSR(stub):
    CLOSE_TEST_APP(stub)
    return IS_RUNNING_TEST_APP(stub) != True

# Check test app close with HW back button
def closeAppTest2(stub):
    BACK(stub)     
    return IS_RUNNING_TEST_APP(stub) != True
    
def lightSetup(stub):
    SR_STOP()
    SR_START()
    RELAUNCH_TEST_APP(stub)

def defaultSetup(stub):
    lightSetup(stub)
    TAP(stub, "Set custom highlight")
    DOUBLE_TAP(stub)

def defaultTearDown(stub):
    CLOSE_TEST_APP(stub)
    SR_STOP()

def CommonForwardNavigation(stub):
    if TAP(stub, "NUI Test App") is False:
        return False

    # Testing forward navigation
    # Default navigation test
    # expected navigation direction: 0->1->2->3->4
    for id in ["0", "1", "2", "3", "4"]:
        FLICK_RIGHT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    # Custom navigation test
    # expected navigation direction: a->d->c->b->e
    # X is the element outside the focus chain
    # and should be omitted when navigating next/prev
    for id in ["a", "d", "c", "b", "e"]:
        FLICK_RIGHT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    # Default navigation test
    # expected navigation direction: A->B->C->D->E
    for id in ["A", "B", "C", "D", "E"]:
        FLICK_RIGHT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    # focus chain end - highlight should not move
    FLICK_RIGHT(stub)
    
    if not isHighlighted(stub, "item_E"):
        return False    

    #Scenario with tapping the element outside the focus chain:
    if TAP(stub, "X") is False:
        return False
    if not isHighlighted(stub, "item_X"):
        return False

    for id in ["d", "c", "b", "e"]:
        FLICK_RIGHT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    # Default navigation part
    # expected navigation direction: A->B->C->D->E
    for id in ["A", "B", "C", "D", "E"]:
        FLICK_RIGHT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    # focus chain end - highlight should not move
    FLICK_RIGHT(stub)
    if not isHighlighted(stub, "item_E"):
        return False

    return True

def CommonBackwardNavigation(stub):
    if TAP(stub, "Back") is False:
        return False
    if not isHighlighted(stub, "backButton"):
        return False

    #checking focus chain end behavior
    FLICK_LEFT(stub)
    if not isHighlighted(stub, "backButton"):
        return False

    # Testing backward navigation

    # Default navigation test
    # expected navigation direction: E->D->C->B->A
    for id in ["E", "D", "C", "B", "A"]:
        FLICK_LEFT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    # Custom navigation test
    # expected navigation direction: e->b->c->d->a
    # X is the element outside the focus chain
    # and should be omitted when navigating next/prev

    for id in ["e", "b", "c", "d", "a"]:
        FLICK_LEFT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    # Default navigation test
    # expected navigation direction: 4->3->2->1->0

    for id in ["4", "3", "2", "1", "0"]:
        FLICK_LEFT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    # Scenario with tapping the element outside the focus chain:
    if TAP(stub, "X") is False:
        return False
    if not isHighlighted(stub, "item_X"):
        return False

    for id in ["c", "d", "a"]:
        FLICK_LEFT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    # Default navigation part
    for id in ["4", "3", "2", "1", "0"]:
        FLICK_LEFT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    return True
    
def CommonCursorMove(stub, editFieldAutoId):
    # Find and tap text field.
    if TAP_BY_AUTOMATION_ID(stub, editFieldAutoId) is False:
         return False

    time.sleep(ACTION_DELAY_LONG)
    # Check if keyboard is hidden
    # TODO this does not work, see comment in the function definition in a11y_test_utils
    # if IS_KEYBOARD_SHOWN(stub):
        # return False

    # Double tap entry to start editing. Expected TTS feedback: "Text field , Edit field" (where "Text field" is a text inside the field)
    # After delay TTS feedback should be: "Editing" and "Keyboard shown"
    DOUBLE_TAP(stub)
    time.sleep(ACTION_DELAY_XLONG)

    # Check if keyboard is shown
    # TODO this does not work, see comment in the function definition in a11y_test_utils
    # if IS_KEYBOARD_SHOWN(stub) is False:
        # return False

    # In dali-toolkit the cursor by default is located at the end of the text field.
    # Flick up to read the text inside the entry field. Expected TTS feedback is "d" -> "l" -> "e" -> "i" -> "f" -> " " -> "t" -> "x" -> "e" -> "T"
    FLICK_UP(stub) # tts("d")
    FLICK_UP(stub) # tts("l")
    FLICK_UP(stub) # tts("e")
    FLICK_UP(stub) # tts("i")
    FLICK_UP(stub) # tts("f")
    FLICK_UP(stub) # tts("Space")
    FLICK_UP(stub) # tts("t")
    FLICK_UP(stub) # tts("x")
    FLICK_UP(stub) # tts("e")
    FLICK_UP(stub) # tts("T")
    
    # Here the keyboard's "Shift on/off" is done,
    # the keyboard buttons AT-SPI IDs change.
    # sleep() is added just as an extra safety measure here.
    time.sleep(ACTION_DELAY_XLONG)

    # Flick down to read the text inside the entry field. Expected TTS feedback is "e" -> "x" -> "t" -> " " -> "f" -> "i" -> "e" -> "l" -> "d"

    FLICK_DOWN(stub) # tts("e")
    FLICK_DOWN(stub) # tts("x")
    FLICK_DOWN(stub) # tts("t")
    FLICK_DOWN(stub) # tts("Space")
    FLICK_DOWN(stub) # tts("f")
    FLICK_DOWN(stub) # tts("i")
    FLICK_DOWN(stub) # tts("e")
    FLICK_DOWN(stub) # tts("l")
    FLICK_DOWN(stub) # tts("d")

    
    # Additional flick, to get to the end of the entry field. No TTS feedback is expected.
    FLICK_DOWN(stub)
    
    time.sleep(ACTION_DELAY_XLONG)

    # Now check if deleting text works correctly
    # Flick up to get after the second letter
    FLICK_UP(stub) # tts("d")
    FLICK_UP(stub) # tts("l")
    FLICK_UP(stub) # tts("e")
    FLICK_UP(stub) # tts("i")
    FLICK_UP(stub) # tts("f")
    FLICK_UP(stub) # tts("Space")
    FLICK_UP(stub) # tts("t")
    FLICK_UP(stub) # tts("x")
    
    # Check if keyboard is shown
    # TODO this does not work, see comment in the function definition in a11y_test_utils
    # if IS_KEYBOARD_SHOWN(stub) is False:
        # return False

    # Remove two letters using BackSpace
    # TODO none of the ways to generate Backspace key stroke works here...
    # The first causes runtime error (seems not to be implemented)
    #response = stub.sendKey(ReqKey(type='KEY', keyCode=8))
    if DOUBLE_TAP_BY_NAME(stub, "BackSpace") is False:
        return False
        
    #tts says: "e deleted"

    # Here the keyboard's "Shift on/off" is done,
    # the keyboard buttons AT-SPI IDs change (including BackSpace),
    # that's why sleep() is needed in this place
    # to provide test execution stability.
    time.sleep(ACTION_DELAY_XLONG)

    # TODO none of the ways to generate Backspace key stroke works here...
    # The first causes runtime error (seems not to be implemented)
    # #response = stub.sendKey(ReqKey(type='KEY', keyCode=8))
    # The second just fails - the SW keyboard is not available in the aurum tree.
    if DOUBLE_TAP_BY_NAME(stub, "BackSpace") is False:
        return False
    
    #tts says: "Capital T deleted"

    return True

def A11Y_BUTTONS_OPERATION(stub):
    # Navigate to the Button page
    if TAP(stub, "Button") is False:
        return False
    DOUBLE_TAP(stub)
    if TAP(stub, "NUI Test App") is False:
        return False

    # Go to button_1
    FLICK_RIGHT(stub)
    # Check button_1 activation action
    button_1 = getObjectByAutomationId(stub, "button_1")
    # Check if button_1 a11y label before click is "Default"
    if not hasWidgetText(button_1, "Default"):
        return False

    DOUBLE_TAP(stub)
    # Check if button_1 a11y label after click is "Click1"
    button_1 = getObjectByAutomationId(stub, "button_1")
    if not hasWidgetText(button_1, "Click1"):
        return False

    # Ommitting button_2 which is not interesting
    FLICK_RIGHT(stub)

    # Go to button_3 which is disabled.
    FLICK_RIGHT(stub)
    # Check button_3 non-responsiveness:
    button_3 = getObjectByAutomationId(stub, "button_3")
    # Check if button_3 a11y label before click is "Disabled".
    if not hasWidgetText(button_3, "Disabled"):
        return False

    # Double tap to try to activate the button.
    # Button is disabled, so activation will not happen.
    # Nothing should change after this action.
    DOUBLE_TAP(stub)
    button_3 = getObjectByAutomationId(stub, "button_3")
    # button_3 a11y label should still be "Disabled"
    if not hasWidgetText(button_3, "Disabled"):
        return False

    # Go to button_4
    FLICK_RIGHT(stub)
    button_4 = getObjectByAutomationId(stub, "button_4")
    # Before activating check if button_4 a11y label is as intended.
    if not hasWidgetText(button_4, "Click to enable the button above"):
        return False

    # Double tap to activate the button.
    # As a result button_3 will be enabled and button_4 will change the label.
    DOUBLE_TAP(stub)
    button_4 = getObjectByAutomationId(stub, "button_4")
    # Check if button_4 a11y label changed as intended.
    if not hasWidgetText(button_4, "Click to disable the button above"):
        return False

    # Go back to button_3
    FLICK_LEFT(stub)
    # Check button_3 responsiveness after it has been enabled.
    button_3 = getObjectByAutomationId(stub, "button_3")
    # button_3 a11y label before click should now be "Enabled"
    if not hasWidgetText(button_3, "Enabled"):
        return False

    # Double tap to activate the button.
    # This time the button is enabled and its activation should cause
    # a11y label to change to "Click3".
    DOUBLE_TAP(stub)
    button_3 = getObjectByAutomationId(stub, "button_3")
    # button_3 a11y label should be now "Click3".
    if not hasWidgetText(button_3, "Click3"):
        return False

    # Go to button_4 one more time
    FLICK_RIGHT(stub)
    button_4 = getObjectByAutomationId(stub, "button_4")
    # Before activating check if button_4 a11y label is as intended.
    if not hasWidgetText(button_4, "Click to disable the button above"):
        return False
    DOUBLE_TAP(stub)
    button_4 = getObjectByAutomationId(stub, "button_4")
    # Check if button_4 a11y label changed as intended.
    if not hasWidgetText(button_4, "Click to enable the button above"):
        return False

    # Go back to button_3 which is disabled again.
    FLICK_LEFT(stub)
    # Check button_3 non-responsiveness again.
    button_3 = getObjectByAutomationId(stub, "button_3")
    # Check if button_3 a11y label before click is "Disabled"
    if not hasWidgetText(button_3, "Disabled"):
        return False

    # Activate the button - nothing should change.
    DOUBLE_TAP(stub)
    button_3 = getObjectByAutomationId(stub, "button_3")
    # Check if button_3 a11y label is still "Disabled"
    if not hasWidgetText(button_3, "Disabled"):
        return False

    return True

def A11Y_CHECKBOXBUTTONS_OPERATION(stub):
    # Navigate to the CheckBoxButton page
    if TAP(stub, "CheckBoxButton") is False:
        return False
    DOUBLE_TAP(stub)
    if TAP(stub, "NUI Test App") is False:
        return False

    # Go to check1
    FLICK_RIGHT(stub)
    check1 = getObjectByAutomationId(stub, "check1")
    if not check1 or stub.getAttribute(ReqGetAttribute(elementId=check1.elementId, attribute='CHECKED')).boolValue != False:
        return False

    DOUBLE_TAP(stub)
    check1 = getObjectByAutomationId(stub, "check1")
    if not check1 or stub.getAttribute(ReqGetAttribute(elementId=check1.elementId, attribute='CHECKED')).boolValue != True:
        return False

    # FIXME This part of the test fails because of aurum tree not refreshing the checkbox unchecked state!    

    DOUBLE_TAP(stub)
    check1 = getObjectByAutomationId(stub, "check1")
    if not check1 or stub.getAttribute(ReqGetAttribute(elementId=check1.elementId, attribute='CHECKED')).boolValue != False:
        return False

    FLICK_RIGHT(stub)
    check2 = getObjectByAutomationId(stub, "check2")
    if not check2 or stub.getAttribute(ReqGetAttribute(elementId=check2.elementId, attribute='CHECKED')).boolValue != True:
        return False
    DOUBLE_TAP(stub)
    check2 = getObjectByAutomationId(stub, "check2")
    if not check2 or stub.getAttribute(ReqGetAttribute(elementId=check2.elementId, attribute='CHECKED')).boolValue != False:
        return False
    DOUBLE_TAP(stub)
    check2 = getObjectByAutomationId(stub, "check2")
    if not check2 or stub.getAttribute(ReqGetAttribute(elementId=check2.elementId, attribute='CHECKED')).boolValue != True:
        return False 

    return True

def A11Y_UI_FORWARD_NAVIGATION(stub):
    # Navigate to the UI reading order page
    if TAP(stub, "UI reading order") is False:
        return False
    DOUBLE_TAP(stub)
    return CommonForwardNavigation(stub)

def A11Y_LEGACY_UI_FORWARD_NAVIGATION(stub):
    # Navigate to the UI reading order page
    if TAP(stub, "Legacy API: UI reading order") is False:
        return False
    DOUBLE_TAP(stub)
    return CommonForwardNavigation(stub)

def A11Y_UI_BACKWARD_NAVIGATION(stub):
    # Navigate to the UI reading order page
    if TAP(stub, "UI reading order") is False:
        return False
    DOUBLE_TAP(stub)
    return CommonBackwardNavigation(stub)
    
def A11Y_UI_LOOPING_NAVIGATION(stub):
    # Navigate to the UI reading order page
    if TAP(stub, "UI reading order") is False:
        return False
    DOUBLE_TAP(stub)
    
    # Highlight the last element of the focus chain
    if TAP(stub, "E") is False:
        return False

    if not isHighlighted(stub, "item_E"):
        return False

    # Perform 1 right flick.
    # Emits sound feedback, highlighted object should not change, no voice feedback expected.
    FLICK_RIGHT(stub)

    #Check if the focus did not change
    if not isHighlighted(stub, "item_E"):
        return False
        
    # Perform 1 right flick.
    # reads aloud "Back" and the first UI element in viewport became highlighted.
    FLICK_RIGHT(stub)
    if isHighlighted(stub, "item_E"):
        return False
    if not isHighlighted(stub, "backButton"):
        return False

    # Perform 1 left flick.
    # Emits sound feedback, highlighted object should not change, no voice feedback expected.
    FLICK_LEFT(stub)

    #Check if the focus did not change
    if not isHighlighted(stub, "backButton"):
        return False

    # Perform 1 left flick.
    # reads aloud "E" and the last UI element in viewport became highlighted.
    FLICK_LEFT(stub)
    

    #Check if the focus changed to last element
    if not isHighlighted(stub, "item_E"):
        return False
    if isHighlighted(stub, "backButton"):
        return False

    return True
    
def A11Y_LEGACY_UI_BACKWARD_NAVIGATION(stub):
    # Navigate to the UI reading order page
    if TAP(stub, "Legacy API: UI reading order") is False:
        return False
    DOUBLE_TAP(stub)
    return CommonBackwardNavigation(stub)

def A11Y_DEFAULT_SORTED_NAVIGATION(stub):
    # Navigate to the UI reading order page
    if TAP(stub, "Reading order sorting") is False:
        return False
    DOUBLE_TAP(stub)

    if TAP(stub, "NUI Test App") is False:
        return False

    # Testing forward navigation
    # Default navigation test
    # expected navigation direction: a -> A -> b -> B -> c -> C -> d -> D -> e -> E
    for id in ["a", "A", "b", "B", "c", "C", "d", "D", "e", "E"]:
        FLICK_RIGHT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    #check focus chain end
    FLICK_RIGHT(stub)
    if not isHighlighted(stub, "item_E"):
        return False

    for id in ["e", "D", "d", "C", "c", "B", "b", "A", "a"]:
        FLICK_LEFT(stub)
        if not isHighlighted(stub, "item_" + id):
            return False

    FLICK_LEFT(stub)
    if not isHighlighted(stub, "titleLabel"):
        return False

    return True

def A11Y_CUSTOM_READING(stub):
    # Navigate to the Reading Customization page
    if TAP(stub, "Reading Customization") is False:
        return False
    DOUBLE_TAP(stub)

    if TAP(stub, "NUI Test App") is False:
        return False

    FLICK_RIGHT(stub)
    label = getObjectByAutomationId(stub, "label")
    if not isHighlightedObject(stub, label) or not hasWidgetText(label, "0"):
        return False

    FLICK_RIGHT(stub)
    inc_button = getObjectByAutomationId(stub, "inc_button")
    if not isHighlightedObject(stub, inc_button) or not hasWidgetText(inc_button, "Increase value"):
        return False
    DOUBLE_TAP(stub)

    # Case 1: "Don't read this button": no info should be read on highlight
    FLICK_RIGHT(stub)
    # omitting checking this case as we don't have access to ReadingInfoTypes attribute in Aurum

    # Case 2: "static A11y info"
    FLICK_RIGHT(stub)
    button_2 = getObjectByAutomationId(stub, "button_2")
    if not isHighlightedObject(stub, button_2) or not hasWidgetText(button_2, "B3 Accessibility name"):
        return False

    # Case 3: "dynamic A11y info"
    FLICK_RIGHT(stub)
    button_3 = getObjectByAutomationId(stub, "button_3")
    if not isHighlightedObject(stub, button_3) or not hasWidgetText(button_3, "name, current value: 1"):
        return False
    if TAP(stub, "Increase value") is False:
        return False
    DOUBLE_TAP(stub)
    # now the value is set to 2
    FLICK_RIGHT(stub)
    FLICK_RIGHT(stub)
    FLICK_RIGHT(stub)
    button_3 = getObjectByAutomationId(stub, "button_3")
    if not isHighlightedObject(stub, button_3) or not hasWidgetText(button_3, "name, current value: 2"):
        return False

    # omitting checking the cases below as we don't have access to ReadingInfoTypes attribute in Aurum
    # Case 4: "description only"
    # A11y name is set, but not read, A11y role is set but not read, A11y description is read: "Only Accessibility description"
    # Case 5: "role&description only"
    # A11y role is read: "Button", A11y description is read: "Accessibility description"
    # Case 6: "name&description only"
    # A11y name is read: "Accessibility name", A11y role is set but not read, A11y description is read: "Accessibility description"
    # Case 7: "default get and set"
    # A11y name, role and description is read

    return True

def A11Y_INCREASE_DECREASE_VALUE(stub):
    # Navigate to the Slider page
    if TAP(stub, "Slider") is False:
        return False
    DOUBLE_TAP(stub)
    time.sleep(ACTION_DELAY_XLONG)

    # Tap the slider.
    if TAP(stub, "TestSlider1") is False:
        return False
    time.sleep(ACTION_DELAY_XLONG)

    # Flick up to increase the value.
    for value in range(5, 101, 5): # 5, 10, 15, ..., 100
        FLICK_UP(stub)
        time.sleep(ACTION_DELAY_LONG)
        controlLabel = getObjectByAutomationId(stub, "mLabel")
        if not hasWidgetText(controlLabel, "Current value: " + str(value)):
            return False

    # Additional flick, to make sure the percentage stays on 100 percent.
    FLICK_UP(stub)
    time.sleep(ACTION_DELAY_LONG)
    controlLabel = getObjectByAutomationId(stub, "mLabel")
    if not hasWidgetText(controlLabel, "Current value: 100"):
        return False

    # Flick down to decrease the value.

    for value in range(95, -1, -5):
        FLICK_DOWN(stub)
        time.sleep(ACTION_DELAY_LONG)
        controlLabel = getObjectByAutomationId(stub, "mLabel")
        if not hasWidgetText(controlLabel, "Current value: " + str(value)):
            return False

    # Additional flick, to make sure the percentage stays on 0 percent.
    FLICK_DOWN(stub)
    time.sleep(ACTION_DELAY_LONG)
    controlLabel = getObjectByAutomationId(stub, "mLabel")
    if not hasWidgetText(controlLabel, "Current value: 0"):
        return False
    return True
    
def A11Y_HIGHLIGHTED_WIDGET_BORDER_RENDER(stub):
    # First let's check if there is no highlight on application startup.
    response = stub.findElement(ReqFindElement(widgetType="ImageView"))
    # There should be exactly 1 image found - an invisible scrollbar
    if len(response.elements) != 1:
        return False
    # Now we highlight "Back" element
    if TAP(stub, "Back") is False:
        return False
    response = stub.findElement(ReqFindElement(widgetType="ImageView"))
    # Now there should be exactly 2 images found - a highlight image and an invisible scrollbar
    if len(response.elements) != 2:
        return False
    # The fist found object is default highlight.
    highlight = response.elements[0]
    # Now we check if the default highlight points exactly to "Back" button
    obj = getObjectByAutomationId(stub, "backButton")
    if highlight and obj.geometry == highlight.geometry:
        return True
    return False

def A11Y_CUSTOM_HIGHLIGHT(stub):
    # Navigate to "Highlight" page
    if TAP(stub, "Highlight") is False:
        return False
    DOUBLE_TAP(stub)
    # move focus on first obj before buttons
    if TAP(stub, "NUI Test App") is False:
        return False

    # Case 1
    # Highlight the first button
    if TAP(stub, "Register custom highlight frame") is False:
        return False

    # check where is the frame
    # this is a temporary solution - we check characteristics of a default highlight frame
    response = stub.findElement(ReqFindElement(widgetType="ImageView"))
    # The fist found object is default highlight.
    highlight = response.elements[0]
    # Now we check if the default highlight points exactly to the tapped button
    obj = getObjectByAutomationId(stub, "button_custom_frame")
    if highlight and obj.geometry != highlight.geometry:
        return False

    # register custom highlight frame
    DOUBLE_TAP(stub)

    # Case 2: Check the highlight order is correct
    FLICK_RIGHT(stub)
    if not isHighlighted(stub, "button_set_frame", "green_highlight"):
        return False

    # Case 3: set custom highlight to button 4
    DOUBLE_TAP(stub)

    # check which object is highlighted
    if not isHighlighted(stub, "button_4", "green_highlight"):
        return False

    # Case 4: manually set custom highlight to button and programmatically clear it
    if TAP(stub, "Clear custom highlight from this button") is False:
        return False
    if not isHighlighted(stub, "button_clear_me", "green_highlight"):
        return False
    DOUBLE_TAP(stub)
    if isHighlighted(stub, "button_clear_me", "green_highlight"):
        return False

    # Case 5: clear highlight from the button which is already cleared
    if TAP(stub, "Clear custom highlight from button 4") is False:
        return False
    if not isHighlighted(stub, "button_clear_4", "green_highlight"):
        return False
    DOUBLE_TAP(stub)
    # check if the currently highlighted object is still highlighted.
    if not isHighlighted(stub, "button_clear_4", "green_highlight"):
        return False

    # Case 6: clear highlight globally
    if TAP(stub, "Clear globally custom highlight") is False:
        return False
    if not isHighlighted(stub, "button_clear_frame", "green_highlight"):
        return False
    DOUBLE_TAP(stub)
    if isHighlighted(stub, "button_clear_frame", "green_highlight"):
        return False

    # Case 7: deregister custom highlight
    if TAP(stub, "Restore default highlight frame") is False:
        return False
    DOUBLE_TAP(stub)
    #check whether a custom highlight frame is still present
    if not isHighlighted(stub, "button_unset_custom_frame", "green_highlight"):
        return False
    # check whether a default frame returned after tap
    if TAP(stub, "4") is False:
        return False
    # first, check if it is not an old frame
    if isHighlighted(stub, "button_clear_frame", "green_highlight"):
        return False
    # check where is the frame
    # this is a temporary solution - we check characteristics of a default highlight frame
    response = stub.findElement(ReqFindElement(widgetType="ImageView"))
    # The fist found object is default highlight.
    highlight = response.elements[0]
    # Now we check if the default highlight points exactly to the tapped button
    obj = getObjectByAutomationId(stub, "button_4")
    if highlight and obj.geometry != highlight.geometry:
        return False

    return True

def A11Y_LEGACY_CUSTOM_HIGHLIGHT(stub):
    # Navigate to "Legacy Highlight" page
    if TAP(stub, "Legacy Highlight") is False:
        return False
    DOUBLE_TAP(stub)
    # move focus on first obj before buttons
    if TAP(stub, "NUI Test App") is False:
        return False

    # Case 1
    # Highlight the first button
    if TAP(stub, "Register custom highlight frame") is False:
        return False

    # check where is the frame
    # this is a temporary solution - we check characteristics of a default highlight frame
    response = stub.findElement(ReqFindElement(widgetType="ImageView"))
    # The fist found object is default highlight.
    highlight = response.elements[0]
    # Now we check if the default highlight points exactly to the tapped button
    obj = getObjectByAutomationId(stub, "button_custom_frame")
    if highlight and obj.geometry != highlight.geometry:
        return False

    # register custom highlight frame
    DOUBLE_TAP(stub)

    # Case 2: Check the highlight order is correct
    FLICK_RIGHT(stub)
    if not isHighlighted(stub, "button_set_frame", "red_highlight"):
        return False

    # Case 3: set custom highlight to button 4
    DOUBLE_TAP(stub)

    # check which object is highlighted
    if not isHighlighted(stub, "button_4", "red_highlight"):
        return False

    # Case 4: manually set custom highlight to button 4 and programmatically clear it
    # no legacy API covering this function.

    # Case 5: clear highlight from the button which is already cleared
    # no legacy API covering this function.

    # Case 6: clear highlight globally
    if TAP(stub, "Clear globally custom highlight") is False:
        return False
    if not isHighlighted(stub, "button_clear_frame", "red_highlight"):
        return False
    DOUBLE_TAP(stub)
    if isHighlighted(stub, "button_clear_frame", "red_highlight"):
        return False

    # Case 7: deregister custom highlight
    # no legacy API covering this function.

    return True

def A11Y_IMAGE_VIEW_NAVIGATION(stub):
    # Navigate to the ImageView page
    if TAP(stub, "ImageView") is False:
        return False
    DOUBLE_TAP(stub)
    # move focus on first obj before images
    if TAP(stub, "NUI Test App") is False:
        return False
    # Test if only highlightable images are being navigatable
    FLICK_RIGHT(stub)
    if not isHighlighted(stub, "HighlightableImg"):
        return False
    FLICK_RIGHT(stub)
    if not isHighlighted(stub, "HighlightableImg2"):
        return False
    # Test at point navigation over an image with name.
    if TAP(stub, "HighlightableImageView") is False:
        return False
    if not isHighlighted(stub, "HighlightableImg"):
        return False
    return True

def A11Y_PAGINATION(stub):
    # WARNING There is no way in Aurum
    # to check AT-SPI Value interface or tts feedback
    # which reflects changing page number in Pagination.
    # So we check only if Pagination is navigatable.
    # In future when we get access to Value interface in Aurum
    # we should check also value changing.
    # Navigate to the Pagination page
    if TAP(stub, "Pagination") is False:
        return False
    DOUBLE_TAP(stub)
    # move focus on first obj before Pagination
    if TAP(stub, "NUI Test App") is False:
        return False
    FLICK_RIGHT(stub)
    if not isHighlighted(stub, "pagination"):
        return False
    # tts reading "Pagination" --> "Page 2 of 5."
    # TODO here we should check the value.
    if TAP(stub, "Next") is False:
        return False
    DOUBLE_TAP(stub)
    FLICK_LEFT(stub)
    if not isHighlighted(stub, "pagination"):
        return False
    # tts reading "Pagination" --> "Page 3 of 5."
    # TODO here we should check if value changed.
    if TAP(stub, "Prev") is False:
        return False
    DOUBLE_TAP(stub)
    DOUBLE_TAP(stub)

    FLICK_LEFT(stub)
    FLICK_LEFT(stub)
    if not isHighlighted(stub, "pagination"):
        return False
    # tts reading "Pagination" --> "Page 1 of 5."
    # TODO here we should check if value changed.
    return True

def A11Y_CURSOR_MOVE_TEXTFIELD(stub):
    # Navigate to the TextField page
    if TAP(stub, "TextField") is False:
        return False
    DOUBLE_TAP(stub)   
    return CommonCursorMove(stub, "textField")
    
def A11Y_CURSOR_MOVE_TEXTEDITOR(stub):
    # Navigate to the TextEditor page
    if TAP(stub, "TextEditor") is False:
        return False
    DOUBLE_TAP(stub)   
    return CommonCursorMove(stub, "textEditor")

# TODO this TC does not work because executing TAP on Label14
# in Aurum returns good result (Label14 is found and tap is done
# on given coordinates) although SW keyboard press is triggered instead.
def A11Y_RESPONSE_AFTER_HIDING_KEYBOARD(stub):
    # Navigate to the TextField page
    if TAP(stub, "TextField") is False:
        return False
    DOUBLE_TAP(stub) 
    # Find and tap text field.
    if TAP_BY_AUTOMATION_ID(stub, "textField") is False:
         return False
    # Double tap entry to start editing. Expected TTS feedback: "Text field , Edit field" (where "Text field" is a text inside the field)
    # After delay TTS feedback should be: "Editing" and "Keyboard shown"
    DOUBLE_TAP(stub)
    time.sleep(ACTION_DELAY_LONG)
    # Label14 should not be accessible now
    if TAP_BY_AUTOMATION_ID(stub, "Label14"):
        return False
    BACK(stub)
    time.sleep(ACTION_DELAY_XLONG)
    # Label14 should be accessible now
    if TAP_BY_AUTOMATION_ID(stub, "Label14") is False:
        return False

def A11Y_PAUSE_RESUME(stub):
    # Navigate to the "Pause/Resume" page
    if TAP(stub, "Pause/Resume") is False:
        return False
    DOUBLE_TAP(stub) 
    # Tap "Read Non-Discardable" button and double tap to activate it.
    if TAP(stub, "Read Non-Discardable") is False:
        return False
    time.sleep(ACTION_DELAY_LONG)

    DOUBLE_TAP(stub)

    # Flick right to "PAUSE/RESUME" button.
    FLICK_RIGHT(stub)
    # Additional tap, to invoke an "ReadingSkipped" event
    if TAP(stub, "PAUSE/RESUME") is False:
        return False
    time.sleep(ACTION_DELAY_LONG)

    # Double tap "PAUSE/RESUME" button to pause tts reading.
    # Then double tap again to resume reading.
    # Finally double tap again to pause reading.
    DOUBLE_TAP(stub)
    time.sleep(ACTION_DELAY_SHORT)
    DOUBLE_TAP(stub)
    time.sleep(ACTION_DELAY_SHORT)
    DOUBLE_TAP(stub)
    time.sleep(ACTION_DELAY_SHORT)

    # Now use gesture to resume and pause the reading.
    # TODO How to emulate 2-finger tap gestures in Aurum?
    # TAP(stub, fingers=2)
    # time.sleep(ACTION_DELAY_LONG)
    # TAP(stub, fingers=2)
    # time.sleep(ACTION_DELAY_LONG)
    
    # currently use HW key emulation in place to keep the consintency in test scenario
    PRESS_XF86_KEY(stub, "XF86AudioPause")
    time.sleep(ACTION_DELAY_SHORT)
    PRESS_XF86_KEY(stub, "XF86AudioPause")
    time.sleep(ACTION_DELAY_SHORT)

    # Now use hardware key to resume and pause the reading.
    PRESS_XF86_KEY(stub, "XF86AudioPause")
    time.sleep(ACTION_DELAY_SHORT)
    PRESS_XF86_KEY(stub, "XF86AudioPause")
    time.sleep(ACTION_DELAY_SHORT)

    # Here we are purging TTS to remove non-discardable reading
    if TAP(stub, "Stop reading") is False:
        return False
    DOUBLE_TAP(stub)

    # go to "eventLog" entry.
    # Make sure that all events were raised properly.
    if TAP(stub, "Event") is False:
        return False
    FLICK_RIGHT(stub)
    FLICK_RIGHT(stub)

    eventLog = getObjectByAutomationId(stub, "mEventLog")
    if not hasWidgetText(eventLog, "ReadingCancelled\nReadingSkipped\nReadingResumed\nReadingPaused\nReadingResumed\nReadingPaused\nReadingResumed\nReadingPaused\nReadingResumed\nReadingPaused\nReadingSkipped\n"):
        return False
    return True

def A11Y_PAUSE_RESUME2(stub):
    # Navigate to the "Pause/Resume" page
    if TAP(stub, "Pause/Resume") is False:
        return False
    DOUBLE_TAP(stub) 
    
    FLICK_RIGHT(stub)
    if TAP(stub, "PAUSE/RESUME") is False:
        return False

    time.sleep(ACTION_DELAY_LONG)

    # Now use hardware key to resume and pause the reading.
    PRESS_XF86_KEY(stub, "XF86AudioPause")
    time.sleep(ACTION_DELAY_LONG)
    PRESS_XF86_KEY(stub, "XF86AudioPause")
    time.sleep(ACTION_DELAY_LONG)

    # Flick right to enter "Event" entry.
    # Make sure that all events were raised properly.

    FLICK_RIGHT(stub)
    FLICK_RIGHT(stub)
    FLICK_RIGHT(stub)
    eventLog = getObjectByAutomationId(stub, "mEventLog")
    if not hasWidgetText(eventLog, "ReadingResumed\nReadingPaused\n"):
        return False
    return True

def A11Y_READING_POPUP(stub):
    # Navigate to the Popup page
    if TAP(stub, "Popup") is False:
        return False
    DOUBLE_TAP(stub)

    if TAP(stub, "Show popup") is False:
        return False
    DOUBLE_TAP(stub)
    time.sleep(ACTION_DELAY_LONG)

    FLICK_RIGHT(stub)
    if not isHighlighted(stub, "PopupContent"):
        return False
    FLICK_RIGHT(stub)
    if not isHighlighted(stub, "OKButton"):
        return False
    FLICK_RIGHT(stub)
    if not isHighlighted(stub, "CancelButton"):
        return False
    FLICK_RIGHT(stub) # FOCUS CHAIN END of the popup

    # Now we expect navigate back to the popup message.
    FLICK_RIGHT(stub) 
    if not isHighlighted(stub, "PopupContent"):
        return False

    # We tap the button but it SHOULD NOT be highlighted as a result
    # The true result of the line below means only that the object was found
    # and tap gesture in the given coordinates was done.
    if TAP_BY_AUTOMATION_ID(stub, "button_1") is False:
        return False
    # Here we check if the tapped object was actually highlighted
    if isHighlighted(stub, "button_1"):
        return False

    if TAP(stub, "Cancel") is False:
        return False
    # Closing the popup
    DOUBLE_TAP(stub)

    # Check if after closing the popup we can navigate the screen again.
    FLICK_RIGHT(stub)
    if not isHighlighted(stub, "backButton"):
        return False
    return True

#========================================================================
# TEST SUITE (this was based on default template from Aurum test samples)
#========================================================================

def runTest(stub, testFunc, setup=defaultSetup, tearDown=defaultTearDown, alwaysSucceed=False):
    print("Testing started :", testFunc)

    setup(stub)
    result = testFunc(stub)
    tearDown(stub)

    print("Testing result :", result)
    if alwaysSucceed:
        return True
    else:
        return result

def runTestWithoutSetupAndTearDown(stub, testFunc, setup=defaultSetup, tearDown=defaultTearDown):
    def Empty(stub):
        pass

    runTest(stub, testFunc, Empty, Empty)

def run():
    with grpc.insecure_channel('127.0.0.1:50051') as channel:
        stub = BootstrapStub(channel)

        runTestWithoutSetupAndTearDown(stub, launchAppTestNoSR)
        runTestWithoutSetupAndTearDown(stub, closeAppTestNoSR)
        runTestWithoutSetupAndTearDown(stub, launchAppTest)
        runTestWithoutSetupAndTearDown(stub, closeAppTest)

        runTest(stub=stub, testFunc=A11Y_HIGHLIGHTED_WIDGET_BORDER_RENDER, setup=lightSetup, tearDown=defaultTearDown)
        runTest(stub, A11Y_CUSTOM_HIGHLIGHT, setup=lightSetup, tearDown=defaultTearDown)
        runTest(stub, A11Y_LEGACY_CUSTOM_HIGHLIGHT, setup=lightSetup, tearDown=defaultTearDown)

        runTest(stub, A11Y_BUTTONS_OPERATION)
        runTest(stub, A11Y_CHECKBOXBUTTONS_OPERATION)
        runTest(stub, A11Y_UI_FORWARD_NAVIGATION)
        runTest(stub, A11Y_UI_BACKWARD_NAVIGATION)
        runTest(stub, A11Y_LEGACY_UI_FORWARD_NAVIGATION)
        runTest(stub, A11Y_LEGACY_UI_BACKWARD_NAVIGATION)
        runTest(stub, A11Y_DEFAULT_SORTED_NAVIGATION)
        runTest(stub, A11Y_CUSTOM_READING)
        runTest(stub, A11Y_INCREASE_DECREASE_VALUE)
        runTest(stub, A11Y_IMAGE_VIEW_NAVIGATION)
        runTest(stub, A11Y_PAGINATION)
        runTest(stub, A11Y_UI_LOOPING_NAVIGATION)
        runTest(stub, A11Y_PAUSE_RESUME)
        runTest(stub, A11Y_PAUSE_RESUME2)
        runTest(stub, A11Y_READING_POPUP)
        
        # The following three TCs fail, see code comments for details.
        # They also cause random hangups of the test suite so I commented them out
        # runTest(stub, A11Y_CURSOR_MOVE_TEXTFIELD)
        # runTest(stub, A11Y_CURSOR_MOVE_TEXTEDITOR)
        # runTest(stub, A11Y_RESPONSE_AFTER_HIDING_KEYBOARD)

if __name__ == '__main__':
    logging.basicConfig()
    run()
